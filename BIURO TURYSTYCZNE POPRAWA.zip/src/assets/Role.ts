export interface Role {
  guest: boolean;
  client: boolean;
  manager: boolean;
  admin: boolean;
  banned: boolean;
}
