export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: 'AIzaSyAVPRXTV1BTo7ZRmHwtTt6WwrdPWdVwcyI',
    authDomain: 'probny-projekt-9fd82.firebaseapp.com',
    databaseURL:
      'https://probny-projekt-9fd82-default-rtdb.europe-west1.firebasedatabase.app',
    projectId: 'probny-projekt-9fd82',
    storageBucket: 'probny-projekt-9fd82.appspot.com',
    messagingSenderId: '143095752679',
    appId: '1:143095752679:web:647a8badb16b7193907f42',
    measurementId: 'G-97K2DWSFPD',
  },
};
